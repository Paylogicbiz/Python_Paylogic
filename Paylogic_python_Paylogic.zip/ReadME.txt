1. create a folder of your choice.
2. Open terminal on the folder and create a virtual env by using following command.
->pip install virtual env->install dependencies
->virtualenv env->creates a folder and add dependencies.
3. Use this command in the powershell as an admin befor running the virtual env 
-->Set-ExecutionPolicy unrestricted
4. Activate the virtual env
-->.\env\Scripts\activate.ps
5.Install flask with the command
-->pip install flask
6. Copy paste the content provided in the folder to your project
7. Run project using following command:
-->python .\Api.py 