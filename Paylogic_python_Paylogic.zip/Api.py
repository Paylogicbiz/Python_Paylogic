from locale import currency
from flask import Flask,render_template,request
app = Flask(__name__)
import hashlib

@app.route('/')
def index():
    return render_template('index.html')



@app.route('/sendRequest',methods=['POST'])
def post():
    if request.method=='POST':
        applicationid=request.form['appid']
        order_no=request.form['order_no']
        amount=request.form['amount']
        txntype=request.form['txn_type']
        customer_name=request.form['cust_name']
        address=request.form['Address']
        zipcode=request.form['ZIPCODE']
        contact_no=request.form['mobile']
        emailid=request.form['email']
        currency_code="356"
        return_url=request.form['return_url']
        global key
        key=request.form['secret_key']


        data = {
             'AMOUNT':amount,
            'CURRENCY_CODE': currency_code,
            'CUST_EMAIL': emailid,
            'CUST_NAME': customer_name,
            'CUST_PHONE':contact_no,
            'CUST_STREET_ADDRESS1':address,
            'CUST_ZIP':zipcode,
            'ORDER_ID':order_no,
            'APP_ID':applicationid,
            'RETURN_URL':return_url,
            'TXNTYPE':txntype
            }

       



       
        hash = checksum(data)

        print(hash)


        return render_template("sendRequest.html", applicationid=applicationid, 
        order_no=order_no,amount=amount,
        txntype=txntype,customer_name=customer_name,
        address=address,zipcode=zipcode,
        contact_no=contact_no,emailid=emailid,
        currency_code=currency_code,return_url=return_url,
        hash=hash
        )

        


def checksum(data):
            datasort = {k :v for k, v in sorted(data.items())}
            sortD = '~'.join('%s=%s'%x for x in datasort.items())
            sortD+= key
            hashing=hashlib.sha256(sortD.encode())
            checksum = hashing.hexdigest()
            return checksum.upper()
        



@app.route('/response',methods=['POST'])
def validateResponse():
    if request.method=='POST':
        
        time = request.form['RESPONSE_DATE_TIME'].replace("+"," ")

        print(time)

        resonsedata ={
            'RESPONSE_DATE_TIME':time,
            'RESPONSE_CODE': request.form['RESPONSE_CODE'],
            'STATUS': request.form['STATUS'],
            'APP_ID':request.form['APP_ID'],
            'TXN_ID':request.form['TXN_ID'],
            'TXNTYPE':request.form['TXNTYPE'],
            'RETURN_URL':request.form['RETURN_URL'],
            'ORDER_ID':request.form['ORDER_ID']
}

    if "ACQ_ID" in request.form:
            resonsedata["ACQ_ID"] = request.form["ACQ_ID"]
    if "CARD_MASK" in request.form:
            resonsedata["CARD_MASK"] = request.form["CARD_MASK"]
    if "DUPLICATE_YN" in request.form:
            resonsedata["DUPLICATE_YN"] = request.form["DUPLICATE_YN"]
    if "MOP_TYPE" in request.form:
            resonsedata["MOP_TYPE"] = request.form["MOP_TYPE"]
    if "RRN" in request.form:
            resonsedata["RRN"] = request.form["RRN"]
    if "ORIG_TXN_ID" in request.form:
            resonsedata["ORIG_TXN_ID"] = request.form["ORIG_TXN_ID"]
    if "PAYMENT_TYPE" in request.form :
            resonsedata["PAYMENT_TYPE"] = request.form["PAYMENT_TYPE"]
    if "RESPONSE_MESSAGE" in request.form:
            resonsedata["RESPONSE_MESSAGE"] = request.form["RESPONSE_MESSAGE"]
    if "CUST_PHONE" in request.form:
            resonsedata["CUST_PHONE"]= request.form["CUST_PHONE"]
    if "CUST_NAME" in request.form:
            resonsedata["CUST_NAME"] = request.form["CUST_NAME"]
    if "CUST_EMAIL" in request.form:
            resonsedata["CUST_EMAIL"]= request.form["CUST_EMAIL"]
    if "CURRENCY_CODE" in request.form:
            resonsedata["CURRENCY_CODE"]=request.form["CURRENCY_CODE"]
    if "AMOUNT" in request.form:
            resonsedata["AMOUNT"]=request.form["AMOUNT"]
    if "AUTH_CODE" in request.form:
            resonsedata["AUTH_CODE"]=request.form["AUTH_CODE"]
    


    
    hashing = checksum(resonsedata)

    


    response = "Checksum Mismatched"
    
    if(request.form['HASH'] == hashing):
            response = "Checksum Matched"
    

    if "RESPONSE_MESSAGE" in request.form:
        message= request.form["RESPONSE_MESSAGE"]
    else:
        message = "Failed"


    

          
    return render_template("response.html",response=response,
    message=message,
    appid=request.form['APP_ID'],
    transactionid=request.form['TXN_ID'],
    status=request.form['STATUS'],
    time=time,
    orderno=request.form['ORDER_ID']
    )

   
    


if __name__ == "__main__":
    app.run(debug=True,port=8001)